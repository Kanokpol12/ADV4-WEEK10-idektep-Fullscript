#ifndef PATH_FUNCTION2_H
#define PATH_FUNCTION2_H

void pickAndplace_object1();
void pickAndplace_object2();
void pickAndplace_object3();
void pickAndplace_object4();
void pickAndplace_object5();



#endif



